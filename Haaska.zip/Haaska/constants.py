# constants.py

# Your AWS access key
AWS_ACCESS_KEY = "AKIAT7IOQTFWEDANVKEN"

# Your AWS secret key
AWS_SECRET_KEY = "HQpZCgODIfzvZm8v58zE6aMq7BYt+A4po3bnp+Oy"

# AWS region (options: "us-east-1", "eu-west-1", "us-west-2")
AWS_REGION = "eu-west-1"

# Your Home Assistant URL
HOME_ASSISTANT_URL = "https://hassassistant.xyz"

# Your Bearer token
BEARER_TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiIzODk5NDNmYjAwMGM0ZjIzOTYwZDE1ODQxYzE1MTRmMyIsImlhdCI6MTY4NDE1ODM5NCwiZXhwIjoxOTk5NTE4Mzk0fQ.7YnANWx11uaDuYgxV4ne2RTKmiVxh9tBnKYJrP6y3OQ"

# Your Alexa Skill ID
ALEXA_SKILL_ID = "amzn1.ask.skill.5198c150-6e83-4f19-8304-ed1b426d297b"
