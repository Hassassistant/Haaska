# Check if Python is installed
$python = Get-Command python -ErrorAction SilentlyContinue

# If Python is not installed, download and install it
if (-not $python) {
    Write-Host "Python not found. Downloading and installing Python..."

    # Download Python
    Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.9.5/python-3.9.5-amd64.exe" -OutFile "python-3.9.5-amd64.exe"

    # Install Python
    Start-Process -Wait -FilePath .\python-3.9.5-amd64.exe -ArgumentList "/passive", "InstallAllUsers=1", "PrependPath=1"
}

# Install necessary Python packages
& python -m pip install --upgrade pip
& python -m pip install boto3

# Run the Python script
& python .\main.py
