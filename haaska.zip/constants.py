# constants.py

# Your AWS access key
AWS_ACCESS_KEY = ""

# Your AWS secret key
AWS_SECRET_KEY = ""

# AWS region (options: "us-east-1", "eu-west-1", "us-west-2")
AWS_REGION = ""

# Your Home Assistant URL
HOME_ASSISTANT_URL = ""

# Your Bearer token
BEARER_TOKEN = ""

# Your Alexa Skill ID
ALEXA_SKILL_ID = ""
