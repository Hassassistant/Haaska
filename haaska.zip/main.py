from constants import AWS_ACCESS_KEY, AWS_SECRET_KEY, AWS_REGION, HOME_ASSISTANT_URL, BEARER_TOKEN, ALEXA_SKILL_ID
import boto3
import json
import time
import os
import zipfile
import subprocess
import sys

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Install boto3
install("boto3")

# Set up boto3
session = boto3.Session(
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
    region_name=AWS_REGION,
)

# Create IAM client
iam = session.client('iam')

# Define the trust policy document which allows AWS Lambda to assume this role
trust_policy = json.dumps({
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lambda.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
})

# Create the role
response = iam.create_role(
    RoleName='HaaskaLambdaRole',
    AssumeRolePolicyDocument=trust_policy,
    Description='Role for Haaska Lambda function',
)

role_arn = response['Role']['Arn']
print("Role created successfully. ARN: ", role_arn)

# Give it a moment to propagate
time.sleep(20)

# Attach AWSLambdaBasicExecutionRole policy
iam.attach_role_policy(
    RoleName='HaaskaLambdaRole',
    PolicyArn='arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole'
)

# Attach AWSLambdaVPCAccessExecutionRole policy
iam.attach_role_policy(
    RoleName='HaaskaLambdaRole',
    PolicyArn='arn:aws:iam::aws:policy/service-role/AWSLambdaVPCAccessExecutionRole'
)

print("Policies attached successfully.")

# Update config.json
config = {
    "url": HOME_ASSISTANT_URL,
    "bearer_token": BEARER_TOKEN,
    "debug": False,
    "ssl_verify": True,
    "ssl_client": []
}

# Get current directory
current_dir = os.path.dirname(os.path.realpath(__file__))
config_path = os.path.join(current_dir, 'haaska', 'config.json')

with open(config_path, 'w') as f:
    json.dump(config, f, indent=4)

print("config.json has been updated.")

# Zip the haaska directory
zip_name = "haaska.zip"
zip_path = os.path.join(current_dir, zip_name)
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(os.path.join(current_dir, 'haaska')):
        for file in files:
            zipf.write(os.path.join(root, file), os.path.relpath(os.path.join(root, file), os.path.join(current_dir,             'haaska')))

print(f"{zip_name} has been created.")

client = session.client('lambda')

# Create a new AWS Lambda function
with open(zip_path, 'rb') as zipf:
    response = client.create_function(
        FunctionName='haaska',
        Runtime='python3.9',
        Role=role_arn,  # Use the ARN of the created role
        Code={
            'ZipFile': zipf.read()
        },
        Handler='haaska.event_handler',
        Description='A function for Alexa Home Assistant',
    )

print("Function created successfully. ARN: ", response['FunctionArn'])


# Add permission for Alexa to invoke your function
response = client.add_permission(
    FunctionName='haaska',
    StatementId='AlexaFunctionPermission',
    Action='lambda:InvokeFunction',
    Principal='alexa-connectedhome.amazon.com',
    EventSourceToken=ALEXA_SKILL_ID
)


print("Trigger added successfully.")

